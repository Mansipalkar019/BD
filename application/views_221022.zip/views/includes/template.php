<?php
$this->load->view("includes/header.php");
$this->load->view("includes/navbar.php");
$this->load->view("includes/left-sidebar.php");
$this->load->view("includes/right-sidebar.php");
$this->load->view($main_content);
$this->load->view("includes/footer.php");

?>
