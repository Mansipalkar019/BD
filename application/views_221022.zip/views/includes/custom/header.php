<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8" />
    <title>BDCRM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Responsive bootstrap 4 admin template" name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.ico">

    <!-- App css -->
    <link href="<?php echo base_url();?>public/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" 
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>


    <body class="">


<style>
pre {
    /* white-space:pre-line; */
    white-space: pre-wrap;       /* Since CSS 2.1 */
    white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
    white-space: -pre-wrap;      /* Opera 4-6 */
    white-space: -o-pre-wrap;    /* Opera 7 */
    word-wrap: break-word;       /* Internet Explorer 5.5+ */
    font-size: 11px;
}
.card-body p { font-size:12.11px; }
.card-header { font-size: 0.7rem!important; }

html, body
{
    overflow: hidden;
    height: 100%;
}
body { padding: 1px;  }
.container-fluid { padding: 0px; margin: 0px; } /*padding-top: 55px;*/
.row1
{
    overflow-y: scroll;
    overflow-x: hidden;
}

.col-form-label
{
    font-size: 13px;
}


/* [class*="col-"]{ */
    /* margin-bottom: -99999px;
    padding-bottom: 99999px; */
    /* overflow: auto; */
/* } */
/* .col
{
    padding: 0px;
    margin: 0px;
} */
</style>

   
